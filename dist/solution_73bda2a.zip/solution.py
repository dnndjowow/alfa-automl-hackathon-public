"""Точка входа платформы: python3 solution.py task.md (из каталога задачи).

Порядок: страховочный ответ -> LLM-агент управляет экспериментами -> код гарантирует, что
в submission.csv лежит лучший обученный запуск. Если LLM недоступна или не довела дело до
обученной модели, тот же набор инструментов работает по простой фиксированной политике.

Переменные окружения:
  OPENAI_API_KEY, OPENAI_BASE_URL, OPENAI_MODEL — выданная модель (обязательны для агента);
  AGENT_TIME_LIMIT — общий лимит секунд (по умолчанию 10800 = 3 часа платформы);
  AGENT_SAFETY_S — запас до лимита на запись ответа и выход (по умолчанию 900);
  AGENT_MAX_STEPS — максимум шагов диалога с моделью (по умолчанию 40);
  AGENT_LLM=off — не обращаться к LLM (офлайн-проверки, чтобы не тратить общий бюджет ключа);
  AGENT_STABILIZE=on — перепроверять лучших кандидатов на другом разбиении (маленькие данные; идёт A/B).
"""

from __future__ import annotations

import os
import sys
import time
from pathlib import Path

START = time.monotonic()
# модули решения лежат рядом с solution.py: импорт не должен зависеть от способа запуска
sys.path.insert(0, str(Path(__file__).resolve().parent))


# вывод в файл на Windows идёт в кодировке локали (cp1251): символ из ответа LLM ронял print и весь агент
try:
    sys.stdout.reconfigure(encoding="utf-8", errors="backslashreplace")
    sys.stderr.reconfigure(encoding="utf-8", errors="backslashreplace")
except Exception:
    pass


def log(message: str) -> None:
    elapsed = time.monotonic() - START
    line = f"[{elapsed:7.1f}s] {message}"
    try:
        print(line, flush=True)
    except Exception:  # журнал никогда не должен останавливать решение
        try:
            print(line.encode("ascii", "backslashreplace").decode("ascii"), flush=True)
        except Exception:
            pass


def load_local_env() -> None:
    """Локальная разработка: .env рядом с solution.py. На платформе файла нет, переменные уже заданы."""
    path = Path(__file__).resolve().parent / ".env"
    if path.is_file():
        try:
            from dotenv import load_dotenv
            load_dotenv(path, override=False)
        except Exception as error:
            log(f".env не прочитан: {type(error).__name__}")


def fallback_policy(session) -> None:
    """Без LLM: эвристическая постановка (или уже выбранная LLM), одна сильная база, финальное обучение."""
    if session.setup is None:
        suggested = session.overview()["suggested"]
        targets, task_type = suggested["target_cols"], suggested["task_type"]
        if not targets:
            log("[fallback] таргет не найден")
            return
        if len(targets) > 1 or task_type not in ("regression", "binary", "multiclass"):
            import ml_schema
            # несколько таргетов: тип по первому; учатся таргеты того же типа, остальные получат константу
            # текст условия общий и не говорит, к какому таргету относится: для остальных — только данные
            kinds = {t: ml_schema.suggest_task_type(session.data.train[t], session.data.text if i == 0 else "")["type"]
                     for i, t in enumerate(targets)}
            task_type = kinds[targets[0]]
            targets = [t for t in targets if kinds[t] == task_type]
        if task_type not in ("regression", "binary", "multiclass"):
            log(f"[fallback] тип задачи {task_type!r} не поддержан")
            return
        metric = suggested["metric"]
        family = "regression" if task_type == "regression" else "classification"
        if metric is None or metric_family(metric) != family:
            metric = ("rmse" if family == "regression"
                      else "roc_auc" if task_type == "binary" and session.sample_suggests_proba() else "f1_macro")
        result = session.call("set_task", {"target_cols": targets, "id_cols": suggested["id_cols"],
                                           "task_type": task_type, "metric": metric, "reason": "fallback"})
        if not result.get("ok") and len(targets) > 1:
            result = session.call("set_task", {"target_cols": targets[:1], "id_cols": suggested["id_cols"],
                                               "task_type": task_type, "metric": metric, "reason": "fallback"})
        if not result.get("ok"):
            log(f"[fallback] set_task: {result.get('error')}")
            return
    improve(session)


def improve(session) -> None:
    """Без LLM: база, затем несколько проверенных на табличных задачах шагов и смесь — пока хватает времени."""
    # условие говорит «test позже train», а столбца времени нет: база сразу на схеме по порядку строк
    by_row_order = (session.plan.get("strategy") != "temporal" and session.rows_look_time_ordered()
                    and not session._ok_runs() and os.environ.get("AGENT_ROW_ORDER", "off").lower() == "on")
    # по умолчанию выключено: Bank Marketing test AUC +0.0075, Bike RMSLE 0.3552 -> 0.3865 (хуже)
    setup = session.setup
    regression = setup["task_type"] == "regression"
    log_metric = setup["metric"] in ("rmsle", "msle")
    y = next(iter(setup["splits"].values())).y_train
    nonneg_skewed = regression and float(y.min()) >= 0 and abs(float(y.skew())) > 0.75
    transform = "log1p" if log_metric else None
    steps = [{"model": "lightgbm", "target_transform": transform, "hypothesis": "fallback: база"}]
    if by_row_order:
        steps[0]["validation"] = {"strategy": "temporal", "column": "__row_order__"}
    if nonneg_skewed and not log_metric:
        steps.append({"model": "lightgbm", "target_transform": "log1p", "hypothesis": "fallback: скошенный таргет"})
    objective = {"mae": "l1", "mape": "mape"}.get(setup["metric"])
    if objective:   # метрика по модулю ошибки: учим ту же функцию потерь
        steps.append({"model": "lightgbm", "params": {"objective": objective}, "target_transform": transform,
                      "hypothesis": f"fallback: objective {objective} под метрику {setup['metric']}"})
    steps += [{"model": "catboost", "hypothesis": "fallback: вторая модель"},
              {"model": "xgboost", "hypothesis": "fallback: третья модель"}]
    if len(y) >= 5000:   # глубокие деревья узнают повторяющиеся сущности: public-регрессия RMSE 39.3 -> 35.8
        steps.append({"model": "xgboost", "params": {"max_depth": 11, "min_child_weight": 1.0},
                      "hypothesis": "fallback: глубокие деревья"})
        if nonneg_skewed and not log_metric:
            # log1p занижает выбросы, а метрика на исходной шкале: та же модель без преобразования — для смеси
            # (public-регрессия, одиночные XGB: log 32.17, смесь log 0.7 + raw 0.3 — 31.54)
            steps.append({"model": "xgboost", "params": {"max_depth": 11, "min_child_weight": 1.0},
                          "target_transform": "none", "hypothesis": "fallback: глубокие деревья, исходная шкала"})
    # разнородные конфигурации из портфеля AutoGluon (TabRepo): смесь берёт полезные и игнорирует слабые
    steps += [{"model": "lightgbm", "params": {"extra_trees": True}, "hypothesis": "fallback: портфель, extra_trees"},
              {"model": "lightgbm", "params": {"num_leaves": 128, "colsample_bytree": 0.9, "min_child_samples": 3},
               "learning_rate": 0.03, "hypothesis": "fallback: портфель, крупные листья"},
              {"model": "catboost", "params": {"depth": 6, "l2_leaf_reg": 2.15, "max_ctr_complexity": 4,
                                               "one_hot_max_size": 10},
               "learning_rate": 0.069, "hypothesis": "fallback: портфель, catboost"}]
    last = 0.0
    auto_features = True
    for step in steps:
        if step["model"] != "lightgbm" or step is not steps[0]:
            best = session.best_run()
            if best and step.get("target_transform") is None and regression:
                step["target_transform"] = session.runs[best]["config"]["target_transform"]
            reserve = (session.estimate_final_seconds(best) if best else 60.0) * 4 + 120
            if session.time_left() < reserve + 2 * last:
                log("[fallback] времени на следующие шаги нет")
                break
        if session._ok_runs(full_only=True) and step is steps[0]:
            continue  # база уже есть (её сделала LLM)
        if step["hypothesis"].endswith("портфель, catboost") and any(
                session.runs[r]["config"]["model"] == "catboost" and session.runs[r]["result"].get("seconds", 0) > 600
                for r in session._ok_runs(full_only=True)):
            log("[fallback] второй CatBoost пропущен: первый шёл дольше 10 минут")
            continue
        started = time.monotonic()
        result = session.call("evaluate", step)
        last = time.monotonic() - started
        if not result.get("ok"):
            log(f"[fallback] evaluate {step['model']}: {result.get('error')}")
        if auto_features and session._ok_runs(full_only=True):
            auto_features = False
            add_safe_features(session, last)
    blend(session)
    best = session.best_run()
    if best and session.runs[best]["config"]["model"] == "blend":
        best_single = min(session.runs[best]["config"]["members"], key=lambda m: _rank(session, m))
    else:
        best_single = best
    if best_single:
        tune_more(session)


def tune_more(session, skip=()) -> None:
    """tune лучшей модели, затем остальных семейств по убыванию качества — пока есть время; смесь после каждого."""
    if os.environ.get("AGENT_FALLBACK_TUNE", "on").lower() == "off" or not session._ok_runs(full_only=True):
        return
    best_single = session.best_run()
    singles = [r for r in session._ok_runs(full_only=True) if session.runs[r]["config"]["model"] != "blend"]
    order = []
    for run_id in sorted(singles, key=lambda r: _rank(session, r)):
        config = session.runs[run_id]["config"]
        if config["model"] not in [c["model"] for c in order] and config["model"] not in skip:
            order.append(config)
    for number, config in enumerate(order):
        best = session.best_run() or best_single
        reserve = session.estimate_final_seconds(best, 3) + 120
        budget = (0.6 if number == 0 else 0.5) * (session.time_left() - reserve)
        if budget < 120:
            break
        result = session.call("tune", {"model": config["model"], "n_trials": 40, "time_budget_s": budget,
                                       "target_transform": config["target_transform"], "hypothesis": "fallback"})
        log(f"[fallback] tune {config['model']}: ok={result.get('ok')} trials={result.get('trials')} "
            f"best={result.get('best', {}).get('score')}")
        blend(session)


def add_safe_features(session, base_seconds) -> None:
    """Без LLM: частоты категорий и число пропусков — дешёвые признаки без смысла задачи; принимаются кодом
    только при устойчивом выигрыше на тех же фолдах."""
    if session.time_left() < 4 * base_seconds + 300:
        return
    X = session.setup["split"].X_train
    categorical = [c for c in X.columns if not pd_numeric(X[c]) and X[c].nunique() > 2][:15]
    specs = [{"op": "count", "col": c} for c in categorical]
    if X.isna().any(axis=1).mean() > 0.05:
        specs.append({"op": "nan_count"})
    if specs:
        result = session.call("add_features", {"features": specs, "hypothesis": "fallback: частоты и пропуски"})
        log(f"[fallback] add_features: accepted={result.get('accepted')} {result.get('error', '')}")
    # целые «коды» (много значений, но не непрерывная величина) как категории: выигрывает CatBoost
    # со статистиками по таргету, поэтому и проверяем CatBoost'ом
    codes = [c for c in X.columns if pd_numeric(X[c]) and is_code_like(X[c])][:15]
    if codes and session.time_left() > 8 * base_seconds + 300:
        result = session.call("add_features", {"features": [{"op": "as_category", "col": c} for c in codes],
                                               "model": "catboost", "hypothesis": "fallback: коды как категории"})
        log(f"[fallback] as_category: accepted={result.get('accepted')} {result.get('error', '')}")
    import agent_tools
    keys = agent_tools.entity_keys(X, session.setup["split"].X_test)
    if keys and session.time_left() > 6 * base_seconds + 300:
        result = session.call("add_features", {"features": [{"op": "target_mean", "by": k} for k in keys],
                                               "hypothesis": "fallback: таргет той же сущности в других строках"})
        log(f"[fallback] target_mean {keys}: accepted={result.get('accepted')} {result.get('error', '')}")



def is_code_like(series) -> bool:
    values = series.dropna()
    if len(values) < 100 or not (values % 1 == 0).all():
        return False
    unique = values.nunique()
    return 20 < unique < 0.5 * len(values)


def pd_numeric(series) -> bool:
    import pandas as pd
    return pd.api.types.is_numeric_dtype(series)


def _rank(session, run_id):
    score = session._score(run_id)
    return -score if session.setup["higher_is_better"] else score


def blend(session) -> None:
    if len(session._ok_runs(full_only=True)) >= 2:
        result = session.call("blend", {"reason": "fallback"})
        log(f"[fallback] blend: ok={result.get('ok')} {result.get('error', '')}")


def stabilize(session, max_rows: int = 5000) -> None:
    """Маленькие данные: CV шумный, а долгий поиск выбирает «победителя» по шуму. Перепроверить 2–3 лучших
    кандидата на другом разбиении и записать лучший по среднему двух проверок."""
    written = session.written or {}
    if os.environ.get("AGENT_STABILIZE", "off").lower() != "on":   # включится по итогам A/B
        return
    if session.setup is None or not written.get("run_id") or written["run_id"] not in session.runs:
        return
    if len(session.setup["split"].X_train) > max_rows:
        return
    key = session.runs[written["run_id"]]["key"]
    pool = [r for r in session._ok_runs(full_only=True) if session.runs[r]["key"] == key]
    ranked = sorted(pool, key=lambda r: _rank(session, r))[:3]
    candidates = list(dict.fromkeys([written["run_id"]] + ranked))
    if len(candidates) < 2:
        return
    cost = sum(session.estimate_final_seconds(c) for c in candidates) * 3
    if cost > 0.3 * session.time_left():
        log("[stabilize] на перепроверку не хватает времени")
        return
    scores = session.revalidate(candidates)
    if written["run_id"] not in scores or len(scores) < 2:
        return
    sign = 1 if session.setup["higher_is_better"] else -1
    best = max(scores, key=lambda r: sign * scores[r]["mean"])
    log(f"[stabilize] {scores} -> {best}")
    if best != written["run_id"] and session.can_finalize(best):
        result = session._finalize(best)
        log(f"[stabilize] записан {best}: ok={result.get('ok')} {result.get('error', '')}")


def polish(session) -> None:
    """Если время осталось: записанный лучший запуск переобучить средним по нескольким сидам."""
    written = session.written or {}
    run_id = written.get("run_id")
    if not run_id or run_id not in session.runs:
        return
    for seeds in (5, 4, 3, 2):
        if seeds <= written.get("seeds", 1):
            return
        if session.estimate_final_seconds(run_id, seeds) <= 0.7 * session.time_left():
            result = session.call("finalize", {"run_id": run_id, "seeds": seeds})
            log(f"[polish] {run_id} x{seeds} сидов: ok={result.get('ok')} {result.get('error', '')}")
            return


def _two_stage_labels_only(session, schema, prediction_format="auto") -> bool:
    """Схема возвращает метки: шаблон должен содержать один столбец прогноза, а не вероятности классов."""
    if prediction_format == "proba":
        return False
    columns = [c for c in session._output_columns(schema) if c not in schema.id_cols]
    if len(columns) != 1:
        return False
    col = columns[0]
    return col == schema.target_cols[0] or (col not in session.data.train.columns and col not in session.data.test.columns)


def two_stage_reserve(session) -> float:
    """Сколько секунд заранее отложить под two_stage: если по паспорту задача под схему подходит (один таргет, классов
    >= 3, самый частый >= 30%, Macro F1, ответ метками, adversarial AUC > 0.8) — 20% оставшегося времени, иначе 0.
    Без резерва запасная политика и tune заполняют всё время, и схема не успевает (прогон 26.10: нужно 864 с, осталось 423)."""
    if os.environ.get("AGENT_TWO_STAGE", "on").lower() == "off" or session.time_left() < 300:
        return 0.0
    try:
        import ml_data
        import ml_metrics
        import ml_schema
        import ml_tools
        setup = session.setup
        profile = setup["profile"] if setup else session.profile
        primary = (profile.get("metric") or {}).get("primary")
        if profile.get("task", {}).get("type") != "multiclass" or not primary or ml_metrics.get_metric(primary).name != "f1_macro":
            return 0.0
        schema = setup["schema"] if setup else ml_schema.resolve_schema(profile["schema"])
        fmt = setup["prediction_format"] if setup else "auto"
        if len(schema.target_cols) != 1 or not _two_stage_labels_only(session, schema, fmt):
            return 0.0
        split = ml_data.split_task(session.data, schema)
        counts = split.y_train.value_counts(normalize=True)
        if len(counts) < 3 or counts.iloc[0] < ml_tools.BACKGROUND_SHARE:
            return 0.0
        if session.time_left() < 300:
            return 0.0
        check = ml_tools.shift_check(split.X_train, split.X_test, n_jobs=session.n_jobs, seed=session.seed,
                                     time_budget=0.8 * session.time_left())
        if check.get("complete") is False or not check["shifted"] or session.time_left() < 300:
            return 0.0
        return 0.2 * session.time_left()
    except Exception as error:   # паспорт неуверенный или метрика своя — без резерва, как раньше
        log(f"[two_stage] резерв не определён: {type(error).__name__}: {str(error)[:200]}")
        return 0.0


def two_stage(session) -> None:
    """Сдвиг train/test и «фоновый» класс (Normal среди атак): записать ответ ml_tools.fit_predict_two_stage вместо
    ответа агента (Юра, 26.10: public-мультикласс, смесь LightGBM+XGBoost, Macro F1 0.5350 -> 0.5457 на 3 сидах).
    Только один таргет, multiclass, Macro F1, ответ метками, уже записан ответ модели и хватает времени; иначе — ничего."""
    if os.environ.get("AGENT_TWO_STAGE", "on").lower() == "off":
        return
    setup = session.setup
    if setup is None or setup["task_type"] != "multiclass" or len(setup["splits"]) != 1:
        return
    metric = setup.get("metric_obj")
    if metric is None or metric.name != "f1_macro" or not (session.written or {}).get("run_id"):
        return
    if not _two_stage_labels_only(session, setup["schema"], setup["prediction_format"]) or session.time_left() < 300:
        return
    import numpy as np

    import agent_tools
    import ml_tools
    split = setup["split"]
    counts = split.y_train.value_counts(normalize=True)
    if len(counts) < 3 or counts.iloc[0] < ml_tools.BACKGROUND_SHARE:
        return
    # 4 цикла ядра (2 модели × 2 ступени, lr 0.1) ≈ одна оценка LightGBM + одна XGBoost агента (lr 0.05):
    # на public-мультиклассе оценка LightGBM 115 с, вся схема 136 с (Mac)
    seconds = {}
    for run_id in session._ok_runs(full_only=True):
        run = session.runs[run_id]
        model = run["config"]["model"]
        if model in ("lightgbm", "xgboost"):
            seconds[model] = max(seconds.get(model, 0.0), float(run["result"].get("seconds", 0.0)))
    if not seconds:
        log("[two_stage] нет оценок LightGBM/XGBoost, время не оценить: пропуск")
        return
    cost = 1.5 * (seconds.get("lightgbm", seconds.get("xgboost", 0.0)) + seconds.get("xgboost", 2 * seconds.get("lightgbm", 0.0)))
    if session.time_left() < 300 or cost > 0.8 * session.time_left():
        log(f"[two_stage] не хватает времени: нужно ≈{cost:.0f}s, осталось {session.time_left():.0f}s")
        return
    # Проверка сдвига входит в те же 80% остатка: её время вычитается из бюджета обучения.
    deadline = time.monotonic() + 0.8 * session.time_left()
    check = ml_tools.shift_check(split.X_train, split.X_test, n_jobs=session.n_jobs, seed=session.seed,
                                 time_budget=max(0.0, deadline - time.monotonic()))
    if check.get("complete") is False or not check["shifted"]:
        log(f"[two_stage] не включается: {check.get('reason') or 'adversarial AUC ' + str(check.get('auc'))}")
        return
    remaining = deadline - time.monotonic()
    if cost > remaining or session.time_left() < 300:
        log("[two_stage] после проверки сдвига не хватает времени: пропуск")
        return
    out = ml_tools.fit_predict_two_stage(split, setup["profile"], models=("lightgbm", "xgboost"), n_jobs=session.n_jobs,
                                         seed=session.seed, time_budget=remaining, check=check)
    if out["status"] != "ok":
        log(f"[two_stage] {out['status']}: {out.get('reason') or out.get('error')}")
        return
    if time.monotonic() >= deadline:
        log("[two_stage] бюджет исчерпан: остаётся прежний ответ")
        return
    main = setup["schema"].target_cols[0]
    pred = np.asarray(out["pred"], dtype=object)
    frame, notes = session._assemble(setup, {main: (pred, None, np.unique(pred.astype(str)))})
    if time.monotonic() >= deadline:
        return
    path = agent_tools.write_submission(frame, session.task_dir, len(split.X_test), setup["schema"].id_cols)
    session.written = {"run_id": None, "model": "two_stage", "score": None, "replaced": session.written,
                       "two_stage": {k: out[k] for k in ("background", "share_train", "share_test", "auc")}}
    log(f"[two_stage] записан {path}: {out['notes']} за {out['seconds']:.0f}s")


def metric_family(metric):
    import agent_tools
    import ml_metrics
    import re
    if re.sub(r"[^a-z0-9]", "", str(metric).lower()) in agent_tools._BINARY_METRICS:
        return "classification"   # бинарная f1/precision/recall: считает агент по положительному классу
    try:
        return agent_tools.resolve_metric(metric).task
    except ml_metrics.MetricError:
        return None


def ensure_final(session) -> None:
    """После диалога: если лучший запуск честно лучше записанного и время есть — обучить и записать его."""
    if session.setup is None:
        return
    best = session.best_run()
    if best is None or (session.written or {}).get("run_id") == best:
        return
    if not session._better_than_written(best, automatic=True):
        return
    if not session.can_finalize(best):
        log(f"[final] на финальное обучение {best} не хватает времени; остаётся {session.written}")
        return
    result = session.call("finalize", {"run_id": best})
    log(f"[final] finalize {best}: ok={result.get('ok')} {result.get('error', '')}")


def guarded(step, *args) -> None:
    try:
        step(*args)
    except Exception as error:  # ни один шаг не должен лишить нас уже записанного ответа
        log(f"[{step.__name__}] сбой: {type(error).__name__}: {str(error)[:300]}")


def main(argv) -> int:
    task_md = Path(argv[1] if len(argv) > 1 else "task.md").resolve()
    load_local_env()
    limit = float(os.environ.get("AGENT_TIME_LIMIT", 10800))
    safety = float(os.environ.get("AGENT_SAFETY_S", 900))
    deadline = START + limit - safety
    log(f"задача {task_md}; бюджет {limit:.0f}s, запас {safety:.0f}s")
    submission = task_md.parent / "submission.csv"

    import agent_tools
    import agent_llm

    try:
        session = agent_tools.Session(task_md, deadline=deadline, log=log, final_slack=0.5 * safety)
    except Exception as error:
        log(f"данные не загружены: {type(error).__name__}: {str(error)[:300]}")
        copied = agent_tools.copy_sample_submission(task_md)
        log(f"последний рубеж: {'скопирован шаблон ответа' if copied else 'шаблона нет'}")
        return 0 if submission.exists() else 1
    session.write_constant()
    reserve = two_stage_reserve(session)
    if reserve:
        session.deadline -= reserve   # возвращается перед шагом two_stage
        log(f"[two_stage] задача подходит под схему: отложено {reserve:.0f}s")

    try:
        if os.environ.get("AGENT_LLM", "on").lower() == "off":
            raise agent_llm.LLMUnavailable("AGENT_LLM=off: LLM отключена для офлайн-проверки", fatal=True)
        chat = agent_llm.OpenAIChat()
        log(f"модель {chat.model}")
        summary = agent_llm.run_agent(session, chat, max_steps=int(os.environ.get("AGENT_MAX_STEPS", 40)), log=log)
        log(f"[agent] шагов {summary['steps']}, finish: {summary['finished']}, usage: {summary['usage']}")
    except agent_llm.LLMUnavailable as error:
        log(f"[agent] LLM недоступна ({error}); дальше запасная политика")
    except Exception as error:  # ошибка агента не должна лишить нас ответа
        log(f"[agent] сбой: {type(error).__name__}: {str(error)[:300]}")

    if session.setup is None or not session._ok_runs(full_only=True):
        log("[agent] обученной модели нет: запасная политика")
        guarded(fallback_policy, session)
    elif session.time_left() > 600:
        # модель закончила раньше времени: дотюнить семейства, которые она не тюнила, и пересобрать смесь
        tuned = {(e.get("args") or {}).get("model", "lightgbm") for e in session.history if e.get("tool") == "tune"}
        log(f"[agent] осталось {session.time_left():.0f}s: tune_more без {sorted(m for m in tuned if m)}")
        guarded(tune_more, session, tuned)
    guarded(ensure_final, session)
    guarded(stabilize, session)
    session.deadline += reserve
    guarded(two_stage, session)   # при включении записанный run_id = None, и polish ответ не перетирает
    guarded(polish, session)
    if not submission.exists():
        log("submission.csv не создан")
        return 1
    log(f"готово: записан {session.written}; запусков {len(session.runs)}")
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv))
